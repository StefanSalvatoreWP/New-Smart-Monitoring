<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Assignment extends Model
{
    use HasFactory;

    protected $table = 'student_subject_assignments'; // Ensure this matches your table name

    protected $fillable = [
        'student_id',
        'subject_id',
        'section_id',
        'section_name',
        'subject_name',
        'schedule',
    ];

    public function student()
    {
        return $this->belongsTo(Student::class, 'student_id', 'student_id');
    }
}
