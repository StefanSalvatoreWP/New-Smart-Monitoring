<?php

namespace App\Http\Controllers;

use App\Models\IdCard;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Inertia\Inertia;

class IdCardController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'cardWidth' => 'required|integer',
            'cardHeight' => 'required|integer',
            'firstName' => 'required|string',
            'lastName' => 'required|string',
            'idNumber' => 'required|string',
            'photo' => 'nullable|image',
            'signature' => 'nullable|image',
            'academicTrack' => 'required|string',
            'emergencyContactName' => 'required|string',
            'emergencyContactAddress' => 'required|string',
            'emergencyContactTelNo' => 'required|string',
        ]);

        $photoPath = null;
        if ($request->hasFile('photo')) {
            $photoPath = $request->file('photo')->store('id_photos', 'public');
        }

        $signaturePath = null;
        if ($request->hasFile('signature')) {
            $signaturePath = $request->file('signature')->store('id_signatures', 'public');
        }

        $idCard = IdCard::create([
            'card_width' => $request->cardWidth,
            'card_height' => $request->cardHeight,
            'first_name' => $request->firstName,
            'last_name' => $request->lastName,
            'id_number' => $request->idNumber,
            'photo' => $photoPath,
            'signature' => $signaturePath,
            'academic_track' => $request->academicTrack,
            'emergency_contact_name' => $request->emergencyContactName,
            'emergency_contact_address' => $request->emergencyContactAddress,
            'emergency_contact_tel_no' => $request->emergencyContactTelNo,
        ]);

        return response()->json(['message' => 'ID Card created successfully', 'id_card' => $idCard], 201);
    }

    public function index()
    {
        $idCards = IdCard::all();
        if (request()->wantsJson()) {
            return response()->json($idCards);
        }
        return Inertia::render('ListOfAllId', [
            'idCards' => $idCards
        ]);
    }
}
