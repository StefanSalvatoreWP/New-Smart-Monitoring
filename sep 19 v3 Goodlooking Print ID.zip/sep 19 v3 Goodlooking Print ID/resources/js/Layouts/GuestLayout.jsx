import { useColorContext } from '@/Context/ColorContext';
import ColorSelector from '@/Components/ColorSelector';

export default function Guest({ children }) {
    const { color, customBackground } = useColorContext();

    const getBackgroundStyle = () => {
        if (customBackground) {
            return `bg-${customBackground} bg-cover bg-center`;
        }

        switch (color) {
            case 'rgb':
                return 'animate-rgb-gradient';
            case 'halloween':
                return 'bg-gradient-to-br from-orange-500 to-black';
            case 'winter':
                return 'bg-gradient-to-br from-cyan-100 to-blue-300';
            case 'summer':
                return 'bg-gradient-to-br from-yellow-300 to-orange-500';
            default:
                return `bg-gradient-to-br from-${color}-400 to-${color}-600`;
        }
    };

    return (
        <div className={`min-h-screen ${getBackgroundStyle()}`}>
            <ColorSelector />
            <div className="flex flex-col items-center justify-center min-h-screen">
                {children}
            </div>
        </div>
    );
}
