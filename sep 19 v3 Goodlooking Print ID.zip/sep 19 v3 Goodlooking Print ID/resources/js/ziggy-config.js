export const Ziggy = {
    url: 'http://your-app-url.test', // Adjust to your application URL
    // Add more configuration as needed
};
