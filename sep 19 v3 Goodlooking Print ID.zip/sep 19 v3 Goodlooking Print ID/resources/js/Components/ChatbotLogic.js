import axios from 'axios';
import { conversationPatterns, generateResponse } from './knowledge';

class ChatbotLogic {
  constructor() {
    this.users = {};
    this.currentStudent = null;
    this.botName = 'CPC Bot';
    this.emojis = ['😊', '👋', '🎉', '💡', '🌟'];
    this.lastQuestion = null;
  }

  async fetchUserData(name) {
    try {
      const cleanName = name.replace(/[^\w\s]/gi, '').trim();
      const response = await axios.get(`/api/chatbot/search-user?name=${encodeURIComponent(cleanName)}`);
      if (response.data && response.data.users) {
        console.log('User data received:', response.data.users);
        return response.data.users;
      }
    } catch (error) {
      console.error('Error fetching user data:', error.response ? error.response.data : error.message);
    }
    return [];
  }

  async fetchStudentData(name) {
    try {
      const cleanName = name.replace(/[^\w\s]/gi, '').trim();
      console.log('Searching for student:', cleanName); // Add this line for debugging
      const response = await axios.get(`/api/chatbot/search-student?name=${encodeURIComponent(cleanName)}`);
      if (response.data && response.data.students) {
        console.log('Student data received:', response.data.students);
        return response.data.students;
      }
    } catch (error) {
      console.error('Error fetching student data:', error.response ? error.response.data : error.message);
    }
    return [];
  }

  getRandomItem(array) {
    return array[Math.floor(Math.random() * array.length)];
  }

  formatDate(dateString) {
    if (!dateString) return 'an unknown date';
    
    const date = new Date(dateString);
    if (isNaN(date.getTime())) {
      console.error('Invalid date string:', dateString);
      return 'an unknown date';
    }
    
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return date.toLocaleDateString(undefined, options);
  }

  async processMessage(message) {
    const lowerMessage = message.toLowerCase();
    const words = lowerMessage.split(' ');

    // Check for registration request first
    if (lowerMessage.includes('register') || lowerMessage.includes('sign up')) {
      return this.handleRegistrationRequest();
    }

    // Check for student queries
    if (lowerMessage.includes('student')) {
      const potentialNames = words.filter(word => !['student', 'name', 'is', 'there', 'a'].includes(word) && word.length > 2);
      let foundStudents = [];
      for (const name of potentialNames) {
        const students = await this.fetchStudentData(name);
        foundStudents = foundStudents.concat(students);
      }
      if (foundStudents.length > 0) {
        this.currentStudent = foundStudents[0];
        return this.generateMultipleStudentResponse(foundStudents);
      } else {
        return "I'm sorry, I couldn't find any students matching your query. Can you please provide more details or try a different name?";
      }
    }

    // Check for user queries
    if (lowerMessage.includes('user') || lowerMessage.includes('about') || lowerMessage.includes('know') || lowerMessage.includes('talk to')) {
      const potentialNames = words.filter(word => !['user', 'about', 'know', 'talk', 'to'].includes(word) && word.length > 2);
      let foundUsers = [];
      for (const name of potentialNames) {
        const users = await this.fetchUserData(name);
        foundUsers = foundUsers.concat(users);
      }
      if (foundUsers.length > 0) {
        return this.generateMultipleUserResponse(foundUsers);
      } else {
        // If no users found, check for students
        let foundStudents = [];
        for (const name of potentialNames) {
          const students = await this.fetchStudentData(name);
          foundStudents = foundStudents.concat(students);
        }
        if (foundStudents.length > 0) {
          this.currentStudent = foundStudents[0];
          return this.generateMultipleStudentResponse(foundStudents);
        } else {
          return "I'm sorry, I couldn't find any users or students matching your query. Can you please provide more details or try a different name?";
        }
      }
    }

    // If no specific query is matched, use the default response
    return generateResponse('default', lowerMessage);
  }

  async handleRegistrationRequest() {
    return {
      type: 'registration',
      message: "Sure! I can help you register. Please click the button below to open the registration form:",
      action: 'openRegistrationModal'
    };
  }

  generateMultipleStudentResponse(students) {
    if (students.length === 1) {
      return this.generateStudentResponse(students[0]);
    }
    const studentList = students.map(s => s.name).join(', ');
    return `I found multiple students matching your query: ${studentList}. Which one would you like to know more about?`;
  }

  generateMultipleUserResponse(users) {
    if (users.length === 1) {
      return this.generateUserResponse(users[0]);
    }
    const userList = users.map(u => u.name).join(', ');
    return `I found multiple users matching your query: ${userList}. Which one would you like to know more about?`;
  }

  handleStudentFollowUp(message) {
    if (!this.currentStudent) return null;

    if (message.includes('email')) {
      return `The email address for ${this.currentStudent.name} is ${this.currentStudent.email}. ${this.getRandomItem(this.emojis)} Is there anything else you'd like to know about this student?`;
    }
    if (message.includes('grade') || message.includes('level')) {
      return `${this.currentStudent.name} is in College ${this.currentStudent.grade_level}. ${this.getRandomItem(this.emojis)} What else would you like to know?`;
    }
    if (message.includes('id') || message.includes('student id')) {
      return `The student ID for ${this.currentStudent.name} is ${this.currentStudent.student_id}. ${this.getRandomItem(this.emojis)} Is there any other information you need?`;
    }
    if (message.includes('enroll') || message.includes('join')) {
      const enrollmentDate = this.formatDate(this.currentStudent.enrollment_date);
      return `${this.currentStudent.name} enrolled on ${enrollmentDate}. ${this.getRandomItem(this.emojis)} What else can I help you with regarding this student?`;
    }
    return null;
  }

  handleUserQuery(message) {
    const userInfo = `Here's some general information about users in our school system:
    1. We have different types of users, including students, teachers, administrators, and parents.
    2. Each user has a unique profile with information relevant to their role.
    3. User data is kept confidential and is only accessible to authorized personnel.
    4. Users can log in to access various school resources and information.

    Is there any specific aspect of user information you'd like to know more about?`;

    return userInfo;
  }

  generateUserResponse(user) {
    const joinDate = this.formatDate(user.created_at);
    return `Ah yes, I know ${user.name}! ${this.getRandomItem(this.emojis)} They're a ${user.role || 'user'} with the email ${user.email}. ${user.name} joined our community on ${joinDate}. Is there anything specific you'd like to know about ${user.name}?`;
  }

  generateStudentResponse(student) {
    const enrollmentDate = this.formatDate(student.enrollment_date);
    return `Of course! I have information about ${student.name}. ${this.getRandomItem(this.emojis)} 
    ${student.name} is a student with ID ${student.student_id}, currently in College ${student.grade_level}. 
    They enrolled on ${enrollmentDate} and can be reached at ${student.email}. 
    What specific information would you like to know about ${student.name}?`;
  }

  getUsers() {
    return this.users;
  }

  setUsers(users) {
    this.users = users;
  }
}

export default ChatbotLogic;
