import React, { useState } from 'react';
import axios from 'axios';

function RegistrationModal({ isOpen, onClose }) {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        password: '',
        password_confirmation: '',
    });

    const [isSubmitting, setIsSubmitting] = useState(false);
    const [errors, setErrors] = useState({});
    const [successMessage, setSuccessMessage] = useState('');

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);
        setErrors({});
        setSuccessMessage('');

        try {
            const response = await axios.post('/chatbot/register', formData);
            setSuccessMessage(`Registration successful! Your account has been created You can now log in with your new account.`);
            setFormData({
                name: '',
                email: '',
                password: '',
                password_confirmation: '',
            });
        } catch (error) {
            if (error.response && error.response.data && error.response.data.errors) {
                setErrors(error.response.data.errors);
            } else {
                setErrors({ general: 'An unexpected error occurred. Please try again.' });
            }
        } finally {
            setIsSubmitting(false);
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full">
            <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
                <h2 className="text-lg font-bold mb-4">Register</h2>
                {successMessage && <div className="mb-4 text-green-600">{successMessage}</div>}
                <form onSubmit={handleSubmit} className="space-y-4">
                    <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="Name"
                        required
                        className="w-full px-3 py-2 border rounded-md"
                    />
                    {errors.name && <div className="text-red-500">{errors.name[0]}</div>}
                    <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="Email"
                        required
                        className="w-full px-3 py-2 border rounded-md"
                    />
                    {errors.email && <div className="text-red-500">{errors.email[0]}</div>}
                    <input
                        type="password"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                        placeholder="Password"
                        required
                        className="w-full px-3 py-2 border rounded-md"
                    />
                    {errors.password && <div className="text-red-500">{errors.password[0]}</div>}
                    <input
                        type="password"
                        name="password_confirmation"
                        value={formData.password_confirmation}
                        onChange={handleChange}
                        placeholder="Confirm Password"
                        required
                        className="w-full px-3 py-2 border rounded-md"
                    />
                    <button type="submit" disabled={isSubmitting} className="w-full px-3 py-2 bg-blue-500 text-white rounded-md">
                        {isSubmitting ? 'Registering...' : 'Register'}
                    </button>
                </form>
                {errors.general && <div className="mt-4 text-red-500">{errors.general}</div>}
                <button onClick={onClose} className="mt-4 w-full px-3 py-2 bg-gray-300 rounded-md">Close</button>
            </div>
        </div>
    );
}

export default RegistrationModal;
