import React, { useState, useEffect } from 'react';
import { Head, Link, useForm } from '@inertiajs/react';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';

const StudentSchedule = ({ auth, student, subjects: initialSubjects, sections: initialSections, student_id }) => {
    const [selectedSection, setSelectedSection] = useState('');
    const [sectionSubjects, setSectionSubjects] = useState([]);
    const [sections, setSections] = useState(initialSections || []);
    const [subjects, setSubjects] = useState(initialSubjects || []);
    const [notification, setNotification] = useState({ message: '', type: '' });

    const { data, setData, post, processing, errors, reset } = useForm({
        section_id: '',
        subject_ids: [],
    });

    useEffect(() => {
        if (!initialSections) {
            fetchSections();
        }
    }, []);

    useEffect(() => {
        console.log('Selected section state updated:', selectedSection);
    }, [selectedSection]);

    useEffect(() => {
        console.log('Form data state updated:', data);
    }, [data]);

    useEffect(() => {
        const fetchInitialSubjects = async () => {
            try {
                const response = await fetch(`/student-assignments/${student_id}`);
                if (response.ok) {
                    const data = await response.json();
                    setSubjects(data);
                } else {
                    console.error('Failed to fetch initial subjects');
                }
            } catch (error) {
                console.error('Error fetching initial subjects:', error);
            }
        };

        fetchInitialSubjects();
    }, [student_id]);

    const fetchSections = async () => {
        try {
            const response = await fetch('/fetch-sections');
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const sectionsData = await response.json();
            console.log('Fetched sections:', sectionsData);
            setSections(sectionsData);
        } catch (error) {
            console.error('Error fetching sections:', error);
        }
    };

    const handleSectionChange = async (e) => {
        const sectionId = e.target.value;
        console.log('Selected section ID:', sectionId);
        setSelectedSection(sectionId);
        setData('section_id', sectionId); // Ensure this line is correctly updating the form data
        console.log('Data after setting section_id:', { ...data, section_id: sectionId }); // Log the updated data
        if (sectionId) {
            try {
                const response = await fetch(`/sections/${sectionId}/subjects`);
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                const subjectsData = await response.json();
                console.log('Fetched section subjects:', subjectsData);
                setSectionSubjects(subjectsData);
                setData(prevData => ({ ...prevData, subject_ids: [] })); // Reset selected subjects when section changes
            } catch (error) {
                console.error('Error fetching section subjects:', error);
            }
        } else {
            setSectionSubjects([]);
        }
    };

    const handleSubjectToggle = (subjectId) => {
        const updatedSubjectIds = data.subject_ids.includes(subjectId)
            ? data.subject_ids.filter(id => id !== subjectId)
            : [...data.subject_ids, subjectId];
        setData('subject_ids', updatedSubjectIds);
    };

    const handleAssign = async (e) => {
        e.preventDefault();

        if (!data.section_id) {
            setNotification({ message: 'Section ID is required', type: 'error' });
            return;
        }

        try {
            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
            const requestData = {
                student_id,
                section_id: data.section_id,
                subject_ids: data.subject_ids,
            };

            const response = await fetch('/assign-subjects', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken
                },
                body: JSON.stringify(requestData),
            });

            const responseData = await response.json();

            if (!response.ok) {
                throw new Error(responseData.error || 'Failed to assign subjects');
            }

            // Fetch updated subjects
            const updatedSubjectsResponse = await fetch(`/student-assignments/${student_id}`);
            const updatedSubjects = await updatedSubjectsResponse.json();
            setSubjects(updatedSubjects);

            setNotification({ message: 'Subjects assigned successfully', type: 'success' });

            // Reset form state
            setSelectedSection('');
            setSectionSubjects([]);
            setData('section_id', '');
            setData('subject_ids', []);
        } catch (error) {
            console.error('Error assigning subjects:', error);
            setNotification({ message: error.message, type: 'error' });
        }
    };

    const Notification = ({ message, type }) => {
        if (!message) return null;

        const bgColor = type === 'success' ? 'bg-green-100 border-green-400 text-green-700' :
                        type === 'error' ? 'bg-red-100 border-red-400 text-red-700' :
                        'bg-blue-100 border-blue-400 text-blue-700';

        return (
            <div className={`border-l-4 p-4 mb-4 ${bgColor}`} role="alert">
                <p>{message}</p>
            </div>
        );
    };

    return (
        <AuthenticatedLayout user={auth.user}>
            <Head title="Student Schedule" />
            <div className="py-12">
                <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
                    <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div className="p-6 text-gray-900">
                            <div className="flex justify-between items-center mb-4">
                                <h1 className="text-2xl font-bold">Student Schedule</h1>
                                <Link
                                    href={route('students.show', { student_id: student_id })}
                                    className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-700 transition duration-150 ease-in-out"
                                >
                                    Back to Student Info
                                </Link>
                            </div>
                            <div className="mb-4">
                                <p className="font-semibold">Student ID: {student_id}</p>
                                {student ? (
                                    <p className="text-gray-600">
                                        {student.first_name} {student.last_name}
                                    </p>
                                ) : (
                                    <p className="text-gray-600">Loading student information...</p>
                                )}
                            </div>
                            
                            <Notification message={notification.message} type={notification.type} />
                            
                            <div className="mt-6">
                                <h2 className="text-xl font-semibold mb-2">Select Section</h2>
                                {sections.length > 0 ? (
                                    <select
                                        value={selectedSection}
                                        onChange={handleSectionChange}
                                        className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                    >
                                        <option value="">Select a section</option>
                                        {sections.map(section => (
                                            <option key={section.id} value={section.id}>
                                                {section.name} - {section.course}
                                            </option>
                                        ))}
                                    </select>
                                ) : (
                                    <p>Loading sections...</p>
                                )}
                                
                                {sectionSubjects.length > 0 && (
                                    <form onSubmit={handleAssign} className="mt-4">
                                        <h3 className="text-lg font-medium mb-2">Subjects in this section:</h3>
                                        <ul className="space-y-2">
                                            {sectionSubjects.map(subject => {
                                                const isAssigned = subjects.some(s => s.id === subject.id);
                                                return (
                                                    <li key={subject.id} className="flex items-center">
                                                        <input
                                                            type="checkbox"
                                                            id={`subject-${subject.id}`}
                                                            checked={data.subject_ids.includes(subject.id)}
                                                            onChange={() => handleSubjectToggle(subject.id)}
                                                            disabled={isAssigned}
                                                            className="mr-2"
                                                        />
                                                        <label 
                                                            htmlFor={`subject-${subject.id}`}
                                                            className={isAssigned ? 'text-gray-400' : ''}
                                                        >
                                                            {subject.name} {isAssigned && '(Already assigned)'}
                                                        </label>
                                                    </li>
                                                );
                                            })}
                                        </ul>
                                        <button
                                            type="submit"
                                            disabled={processing || data.subject_ids.length === 0}
                                            className="mt-4 px-4 py-2 bg-green-500 text-white rounded hover:bg-green-700 transition duration-150 ease-in-out disabled:opacity-50"
                                        >
                                            {processing ? 'Assigning...' : 'Assign Selected Subjects'}
                                        </button>
                                    </form>
                                )}
                            </div>

                            <div className="mt-8 bg-white p-6 rounded-lg shadow-md">
                                <h2 className="text-2xl font-semibold mb-4 text-gray-800">Current Schedule</h2>
                                {subjects && subjects.length > 0 ? (
                                    <ul className="space-y-3">
                                        {subjects.map(subject => (
                                            <li key={subject.id} className="bg-gray-50 p-3 rounded-md flex justify-between items-center">
                                                <span className="font-medium text-gray-800">
                                                    {subject.subject_name} - {subject.section_name}
                                                </span>
                                                <span className="text-gray-600">{subject.schedule}</span>
                                            </li>
                                        ))}
                                    </ul>
                                ) : (
                                    <p className="text-gray-600 italic">No subjects assigned yet.</p>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
};

export default StudentSchedule;
