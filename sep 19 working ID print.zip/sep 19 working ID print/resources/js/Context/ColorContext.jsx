import React, { createContext, useContext, useState } from 'react';

const ColorContext = createContext();

export const useColorContext = () => useContext(ColorContext);

export const ColorProvider = ({ children }) => {
    const [color, setColor] = useState('blue');
    const [customBackground, setCustomBackground] = useState(null);

    return (
        <ColorContext.Provider value={{ color, setColor, customBackground, setCustomBackground }}>
            {children}
        </ColorContext.Provider>
    );
};
