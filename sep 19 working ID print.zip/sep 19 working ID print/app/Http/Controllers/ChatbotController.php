<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Student;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use Illuminate\Auth\Events\Registered;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rules;

class ChatbotController extends Controller
{
    public function searchUser(Request $request)
    {
        try {
            $name = $request->query('name');
            Log::info('Searching for user: ' . $name);
            $users = User::where('name', 'LIKE', "%{$name}%")->get();
            
            if ($users->isNotEmpty()) {
                Log::info('Users found: ' . $users->count());
                return response()->json(['users' => $users->map(function($user) {
                    return [
                        'name' => $user->name,
                        'email' => $user->email,
                        'role' => $user->role,
                        'created_at' => $user->created_at->toDateTimeString(),
                    ];
                })]);
            } else {
                Log::info('No users found for: ' . $name);
                return response()->json(['message' => 'User not found'], 404);
            }
        } catch (\Exception $e) {
            Log::error('Error searching for user: ' . $e->getMessage());
            return response()->json(['error' => 'Internal Server Error'], 500);
        }
    }

    public function searchStudent(Request $request)
    {
        try {
            $name = $request->query('name');
            Log::info('Searching for student: ' . $name);
            $students = Student::where('first_name', 'LIKE', "%{$name}%")
                ->orWhere('last_name', 'LIKE', "%{$name}%")
                ->get();
            
            if ($students->isNotEmpty()) {
                Log::info('Students found: ' . $students->count());
                return response()->json(['students' => $students->map(function($student) {
                    return [
                        'name' => $student->first_name . ' ' . $student->last_name,
                        'student_id' => $student->student_id,
                        'email' => $student->email,
                        'grade_level' => $student->grade_level,
                        'enrollment_date' => $student->enrollment_date,
                    ];
                })]);
            } else {
                Log::info('No students found for: ' . $name);
                return response()->json(['message' => 'Student not found'], 404);
            }
        } catch (\Exception $e) {
            Log::error('Error searching for student: ' . $e->getMessage());
            return response()->json(['error' => 'Internal Server Error'], 500);
        }
    }

    public function generateRegistrationLink()
    {
        $token = Str::random(32);
        session(['registration_token' => $token]);
        
        $registrationLink = route('chatbot.showRegistrationForm', ['token' => $token]);
        return response()->json(['registration_link' => $registrationLink]);
    }

    public function showRegistrationForm(Request $request, $token)
    {
        // Verify the token
        if ($token !== session('registration_token')) {
            abort(403, 'Invalid registration link');
        }

        // Return a view or JSON response with the registration form data
        return response()->json([
            'form_fields' => [
                'name' => '',
                'email' => '',
                'password' => '',
                'password_confirmation' => '',
                'role' => '',
            ]
        ]);
    }

    public function register(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|lowercase|email|max:255|unique:'.User::class,
            'password' => ['required', 'confirmed', Rules\Password::defaults()],
        ]);

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => 'user',  // Set default role to 'user'
        ]);

        event(new Registered($user));

        return response()->json([
            'message' => 'User registered successfully',
            'user' => [
                'name' => $user->name,
                'email' => $user->email,
                'role' => $user->role,
            ]
        ], 201);
    }

    // You can add more chatbot-related methods here in the future
}
