<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class KnowledgeBaseController extends Controller
{
    public function getKnowledgeBase()
    {
        $knowledgeBase = DB::table('knowledge_base')->get();
        return response()->json($knowledgeBase);
    }

    public function saveKnowledgeBase(Request $request)
    {
        $data = $request->json()->all();
        
        DB::transaction(function () use ($data) {
            foreach ($data as $item) {
                DB::table('knowledge_base')
                    ->updateOrInsert(
                        ['response' => $item['response'], 'word' => $item['word']],
                        ['count' => $item['count']]
                    );
            }
        });

        return response()->json(['message' => 'Knowledge base updated successfully']);
    }

    public function learn(Request $request)
    {
        $data = $request->json()->all();
        Log::info('Received learning data:', $data);
        
        try {
            DB::transaction(function () use ($data) {
                foreach ($data as $item) {
                    $result = DB::table('knowledge_base')
                        ->updateOrInsert(
                            ['response' => $item['response'], 'word' => $item['word']],
                            ['count' => DB::raw('count + 1')]
                        );
                    Log::info('Inserted/Updated item:', ['item' => $item, 'result' => $result]);
                }
            });

            Log::info('Learning completed successfully');
            return response()->json(['message' => 'Learning completed successfully']);
        } catch (\Exception $e) {
            Log::error('Error during learning process:', ['error' => $e->getMessage()]);
            return response()->json(['error' => 'Internal Server Error'], 500);
        }
    }
}
