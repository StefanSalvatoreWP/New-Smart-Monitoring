interface ConversationPatterns {
  greetings: string[];
  farewells: string[];
  wellBeingResponses: string[];
  smallTalk: string[];
  jokes: string[];
  compliments: string[];
  encouragement: string[];
  sympathy: string[];
  advice: string[];
  schoolTopics: string[];
  teachingMethods: string[];
  educationTrends: string[];
  userTopics: string[];
}

export const conversationPatterns: ConversationPatterns = {
  greetings: ['hello', 'hi', 'hey', 'good morning', 'good afternoon', 'good evening', 'what\'s up', 'yo', 'hiya', 'howdy', 'greetings', 'aloha'],
  farewells: ['bye', 'goodbye', 'see you', 'take care', 'farewell', 'catch you later', 'have a good one', 'until next time', 'adios', 'ciao', 'sayonara'],
  wellBeingResponses: ['good', 'fine', 'great', 'okay', 'alright', 'not bad', 'daijoubu', 'daijoubo', 'fantastic', 'wonderful', 'excellent', 'superb', 'terrific', 'fabulous', 'amazing', 'marvelous', 'splendid'],
  smallTalk: [
    'how\'s the weather', 'nice day', 'how\'s it going', 'what\'s new', 'how\'s life', 'how\'s your day', 'how\'s work', 'how\'s school',
    'plans for the weekend', 'how\'s your family', 'seen any good movies', 'read any good books', 'heard any good music',
    'how\'s your project going', 'what do you think about', 'did you hear about', 'what\'s your opinion on'
  ],
  jokes: [
    'Why did the scarecrow win an award? He was outstanding in his field!',
    'Why don\'t scientists trust atoms? Because they make up everything!',
    'What do you call a fake noodle? An impasta!',
    'Why did the math book look so sad? Because it had too many problems.',
    'What do you call a bear with no teeth? A gummy bear!',
    'Why don\'t eggs tell jokes? They\'d crack each other up.',
    'What do you call a sleeping bull? A bulldozer!',
    'Why don\'t skeletons fight each other? They don\'t have the guts.',
    'What do you call a can opener that doesn\'t work? A can\'t opener!',
    'Why did the bicycle fall over? Because it was two-tired!'
  ],
  compliments: [
    'You\'re doing great!',
    'That\'s a brilliant idea!',
    'You have a wonderful way with words.',
    'Your hard work is really paying off.',
    'You have a great sense of humor!',
    'You\'re a natural problem-solver.',
    'Your creativity is inspiring.',
    'You have a unique perspective on things.',
    'Your positive attitude is contagious.',
    'You\'re making a real difference.'
  ],
  encouragement: [
    'You\'ve got this!',
    'Believe in yourself.',
    'Keep pushing forward.',
    'Every step counts, no matter how small.',
    'Your efforts will pay off.',
    'Don\'t give up, you\'re almost there!',
    'You\'re stronger than you think.',
    'Challenges help you grow.',
    'You\'re making progress every day.',
    'Success is just around the corner.'
  ],
  sympathy: [
    'I\'m sorry to hear that.',
    'That must be difficult.',
    'You\'re not alone in this.',
    'It\'s okay to feel that way.',
    'Take all the time you need.',
    'Is there anything I can do to help?',
    'Your feelings are valid.',
    'This too shall pass.',
    'Sending positive thoughts your way.',
    'Remember to be kind to yourself during this time.'
  ],
  advice: [
    'Take a deep breath and count to ten.',
    'Try looking at it from a different perspective.',
    'Break the task into smaller, manageable steps.',
    'Don\'t be afraid to ask for help when you need it.',
    'Remember to take breaks and practice self-care.',
    'Write down your thoughts to organize them better.',
    'Set realistic goals for yourself.',
    'Learn from your mistakes, but don\'t dwell on them.',
    'Surround yourself with positive influences.',
    'Trust your instincts.'
  ],
  schoolTopics: [
    'study tips', 'exam preparation', 'homework help', 'time management', 'note-taking techniques',
    'research skills', 'presentation tips', 'group project strategies', 'academic writing',
    'stress management for students', 'extracurricular activities', 'college applications',
    'scholarship opportunities', 'career guidance', 'student life balance', 'online learning tips',
    'subject-specific help', 'learning styles', 'educational technology', 'student organizations'
  ],
  teachingMethods: [
    'active learning', 'project-based learning', 'flipped classroom', 'cooperative learning',
    'inquiry-based learning', 'differentiated instruction', 'blended learning', 'gamification',
    'problem-based learning', 'experiential learning', 'peer tutoring', 'mastery learning',
    'direct instruction', 'discovery learning', 'scaffolding', 'socratic method',
    'team-based learning', 'case study method', 'role-playing', 'simulation-based learning'
  ],
  educationTrends: [
    'personalized learning', 'artificial intelligence in education', 'virtual reality classrooms',
    'social-emotional learning', 'STEM education', 'global citizenship education', 'mindfulness in schools',
    'competency-based education', 'maker education', 'adaptive learning technologies',
    'micro-credentials', 'open educational resources', 'culturally responsive teaching',
    'universal design for learning', 'trauma-informed teaching', 'digital citizenship',
    'growth mindset', 'project-based assessments', 'computational thinking', 'design thinking in education'
  ],
  userTopics: [
    'users', 'user information', 'user profiles', 'user accounts', 'user roles',
    'user permissions', 'user management', 'user registration', 'user login',
    'user authentication', 'user data', 'user privacy', 'user settings'
  ]
};

export const generateResponse = (category: string, input: string): string => {
  const lowerInput = input.toLowerCase();

  switch (category) {
    case 'greeting':
      return `${getRandomItem(conversationPatterns.greetings)}! How can I assist you today with school-related matters?`;
    case 'farewell':
      return `${getRandomItem(conversationPatterns.farewells)}! Remember, I'm here anytime you need information about our school or students.`;
    case 'wellBeingFollowUp':
      return `I'm ${getRandomItem(conversationPatterns.wellBeingResponses)} to hear that! Is there anything specific about our school or students you'd like to know?`;
    case 'joke':
      return `Here's a little school humor for you: ${getRandomItem(conversationPatterns.jokes)} 😄 Now, how can I help you with any school-related questions?`;
    case 'compliment':
      return `${getRandomItem(conversationPatterns.compliments)} Is there anything about our school or education programs you'd like to discuss?`;
    case 'encouragement':
      return `${getRandomItem(conversationPatterns.encouragement)} Remember, our school is here to support you. What aspect of your education can I assist with?`;
    case 'sympathy':
      return `${getRandomItem(conversationPatterns.sympathy)} Our school community is here to support you. Is there anything about our support services you'd like to know?`;
    case 'advice':
      return `Here's a piece of advice: ${getRandomItem(conversationPatterns.advice)} How can I help you apply this to your school life?`;
    case 'smallTalk':
      return handleSmallTalk(lowerInput);
    case 'schoolTopic':
      return handleSchoolTopic(lowerInput);
    case 'teachingMethod':
      return handleTeachingMethod(lowerInput);
    case 'educationTrend':
      return handleEducationTrend(lowerInput);
    case 'userTopic':
      return handleUserTopic(lowerInput);
    default:
      return handleDefaultResponse(lowerInput);
  }
};

const handleDefaultResponse = (input: string): string => {
  const schoolRelatedWords = [...conversationPatterns.schoolTopics, ...conversationPatterns.teachingMethods, ...conversationPatterns.educationTrends];
  for (const word of schoolRelatedWords) {
    if (input.includes(word)) {
      return `I see you're interested in ${word}. That's an important topic in education. Could you please elaborate on what you'd like to know about ${word} in relation to our school?`;
    }
  }
  return "I'm not quite sure how to respond to that in the context of our school. Could you please clarify or rephrase your question? I'm here to help with information about our students, educational programs, or any other school-related topics.";
};

const getRandomItem = (array: string[]): string => {
  return array[Math.floor(Math.random() * array.length)];
};

const handleSmallTalk = (input: string): string => {
  // Implement more sophisticated small talk handling here
  return "That's an interesting topic! While I enjoy casual conversation, I'm best at helping with school-related questions. Is there anything specific about our school or students you'd like to know?";
};

const handleSchoolTopic = (input: string): string => {
  // Implement responses to various school topics
  return "That's a great question about school! While I don't have specific information on that topic, I can help you find resources or connect you with someone who can provide more details. What exactly would you like to know?";
};

const handleTeachingMethod = (input: string): string => {
  // Implement responses to teaching methods
  return "That's an interesting teaching method! While I don't have specific details on how it's implemented here, I can tell you that our school is always looking for effective ways to enhance student learning. Would you like me to find out more about our current teaching approaches?";
};

const handleEducationTrend = (input: string): string => {
  // Implement responses to education trends
  return "You're right to be interested in that education trend! It's definitely something that's being discussed in many schools. While I don't have specific information on how our school is addressing it, I can help you find out more if you'd like. What aspect of this trend are you most curious about?";
};

const handleUserTopic = (input: string): string => {
  return "Certainly! I can help you with user-related information. What specific aspect of user management or user data would you like to know about? For example, I can provide information on user roles, registration processes, or general user policies in our school system.";
};