<?php

namespace App\Http\Controllers;

use App\Models\Student;
use App\Models\User;
use App\Models\Section;
use App\Models\EnrolledStudent;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Inertia\Inertia;

class DashboardController extends Controller
{
    public function index()
    {
        return Inertia::render('Dashboard');
    }

    public function getStats()
    {
        $totalStudents = Student::count();
        $totalUsers = User::count();
        $totalSections = Section::count();
        $totalEnrolledStudents = EnrolledStudent::count();

        $studentsByGrade = Student::select('grade_level', DB::raw('count(*) as count'))
            ->groupBy('grade_level')
            ->pluck('count', 'grade_level')
            ->toArray();

        $recentEnrollments = EnrolledStudent::with(['student', 'section'])
            ->orderBy('created_at', 'desc')
            ->take(5)
            ->get()
            ->map(function ($enrollment) {
                return [
                    'studentName' => $enrollment->student->first_name . ' ' . $enrollment->student->last_name,
                    'sectionName' => $enrollment->section->name,
                    'date' => $enrollment->created_at->format('Y-m-d'),
                ];
            });

        return response()->json([
            'totalStudents' => $totalStudents,
            'totalUsers' => $totalUsers,
            'totalSections' => $totalSections,
            'totalEnrolledStudents' => $totalEnrolledStudents,
            'studentsByGrade' => $studentsByGrade,
            'recentEnrollments' => $recentEnrollments,
        ]);
    }
}
