<?php

namespace App\Http\Controllers;

use App\Models\Assignment;
use App\Models\Subject;
use App\Models\Section;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Models\Student; // Assuming Student model is defined

class StudentScheduleController extends Controller
{
    public function assignSubjects(Request $request)
    {
        try {
            $validated = $request->validate([
                'student_id' => 'required|exists:students,student_id',
                'section_id' => 'required|exists:sections,id',
                'subject_ids' => 'required|array',
                'subject_ids.*' => 'exists:subjects,id',
            ]);

            $student_id = $validated['student_id'];
            $section_id = $validated['section_id'];
            $subject_ids = $validated['subject_ids'];

            $section = Section::findOrFail($section_id);

            Log::info('Assigning subjects', [
                'student_id' => $student_id,
                'section_id' => $section_id,
                'section_name' => $section->name,
                'subject_ids' => $subject_ids,
            ]);

            foreach ($subject_ids as $subject_id) {
                $subject = Subject::findOrFail($subject_id);
                $assignment = Assignment::updateOrCreate(
                    [
                        'student_id' => $student_id,
                        'subject_id' => $subject_id,
                    ],
                    [
                        'section_id' => $section_id,
                        'section_name' => $section->name,
                        'subject_name' => $subject->name,
                        'schedule' => $subject->schedule,
                    ]
                );
                Log::info('Assignment created or updated', ['assignment' => $assignment]);
            }

            Log::info('Subjects assigned successfully');
            return response()->json(['message' => 'Subjects assigned successfully']);
        } catch (\Exception $e) {
            Log::error('Error assigning subjects', ['error' => $e->getMessage()]);
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function getStudentAssignments($student_id)
    {
        $assignments = Assignment::where('student_id', $student_id)->get();
        return response()->json($assignments);
    }

    public function show($student_id)
    {
        $student = Student::findOrFail($student_id);
        $assignments = Assignment::where('student_id', $student_id)->get();
        $sections = Section::all();

        return Inertia::render('StudentSchedule', [
            'student' => $student,
            'assignments' => $assignments,
            'sections' => $sections,
            'student_id' => $student_id
        ]);
    }
}
