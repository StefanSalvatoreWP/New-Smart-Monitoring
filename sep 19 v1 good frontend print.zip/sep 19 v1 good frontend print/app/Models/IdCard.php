<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class IdCard extends Model
{
    use HasFactory;

    protected $fillable = [
        'card_width',
        'card_height',
        'first_name',
        'last_name',
        'id_number',
        'photo',
        'signature',
        'academic_track',
        'emergency_contact_name',
        'emergency_contact_address',
        'emergency_contact_tel_no',
    ];
}
