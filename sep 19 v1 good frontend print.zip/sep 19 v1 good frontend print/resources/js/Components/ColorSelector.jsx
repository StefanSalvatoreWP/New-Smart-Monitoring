import React, { useState, useEffect } from 'react';
import { useColorContext } from '@/Context/ColorContext';

const ColorSelector = () => {
    const { color, setColor, setCustomBackground } = useColorContext();
    const [rgbColor, setRgbColor] = useState({ r: 0, g: 0, b: 0 });
    const [showAllColors, setShowAllColors] = useState(false);

    const colors = [
        'blue', 'green', 'purple', 'red', 'yellow', 'pink', 'indigo', 'teal',
        'rgb', 'halloween', 'winter', 'summer', 'custom1', 'custom2'
    ];

    useEffect(() => {
        let intervalId;
        if (color === 'rgb') {
            intervalId = setInterval(() => {
                setRgbColor({
                    r: Math.floor(Math.random() * 256),
                    g: Math.floor(Math.random() * 256),
                    b: Math.floor(Math.random() * 256)
                });
            }, 1000);
        }
        return () => clearInterval(intervalId);
    }, [color]);

    const getButtonStyle = (colorOption) => {
        switch (colorOption) {
            case 'rgb':
                return { background: `rgb(${rgbColor.r},${rgbColor.g},${rgbColor.b})` };
            case 'halloween':
                return { background: 'linear-gradient(45deg, #ff6600, #000000)' };
            case 'winter':
                return { background: 'linear-gradient(45deg, #e0f7fa, #4fc3f7)' };
            case 'summer':
                return { background: 'linear-gradient(45deg, #ffeb3b, #ff9800)' };
            case 'custom1':
                return { backgroundImage: 'url("/images/ROG1.jpg")', backgroundSize: 'cover', backgroundPosition: 'center' };
            case 'custom2':
                return { backgroundImage: 'url("/images/ROG2.jpg")', backgroundSize: 'cover', backgroundPosition: 'center' };
            default:
                return { backgroundColor: colorOption };
        }
    };

    const handleColorClick = (selectedColor) => {
        if (selectedColor === 'custom1' || selectedColor === 'custom2') {
            setCustomBackground(selectedColor);
        } else {
            setColor(selectedColor);
            setCustomBackground(null);
        }
        setShowAllColors(false);
    };

    const toggleColorSelector = () => {
        setShowAllColors(!showAllColors);
    };

    return (
        <div className="absolute top-4 left-4">
            {!showAllColors ? (
                <button
                    className="w-8 h-8 rounded-full hover:ring-2 ring-white transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    style={getButtonStyle(color)}
                    onClick={toggleColorSelector}
                />
            ) : (
                <div className="flex flex-wrap max-w-xs gap-2 bg-white p-2 rounded-lg shadow-md">
                    {colors.map((colorOption) => (
                        <button
                            key={colorOption}
                            className={`w-8 h-8 rounded-full hover:ring-2 ring-white transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-${colorOption === 'rgb' || colorOption.startsWith('custom') ? 'blue' : colorOption}-500`}
                            style={getButtonStyle(colorOption)}
                            onClick={() => handleColorClick(colorOption)}
                        />
                    ))}
                </div>
            )}
        </div>
    );
};

export default ColorSelector;
