import React, { useState, useRef,useEffect } from 'react';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head } from '@inertiajs/react';
import { QRCodeSVG } from 'qrcode.react';
import axios from 'axios';

const defaultProfilePic = "/images/DefaultID.png";

const IdMaker = ({ auth }) => {
    const [frontInfo, setFrontInfo] = useState({
        cardWidth: 300,
        cardHeight: 420,
        firstName: '',
        lastName: '',
        idNumber: '',
        photo: null,
        signature: null,
        academicTrack: '',
    });

    const [backInfo, setBackInfo] = useState({
        name: '',
        address: '',
        telNo: '',
        academicTrack: '',
    });

    const photoRef = useRef(null);
    const signatureRef = useRef(null);
    const idPreviewRef = useRef(null);

    const [showModal, setShowModal] = useState(false);
    const [allIdCards, setAllIdCards] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [filteredIdCards, setFilteredIdCards] = useState([]);

    useEffect(() => {
        const results = allIdCards.filter(card =>
            `${card.first_name} ${card.last_name} ${card.id_number} ${card.academic_track}`
                .toLowerCase()
                .includes(searchTerm.toLowerCase())
        );
        setFilteredIdCards(results);
    }, [searchTerm, allIdCards]);

    const handleViewAllIds = async () => {
        try {
            const response = await axios.get('/id-cards', {
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });
            console.log('Fetched ID cards:', response.data);
            setAllIdCards(response.data);
            setShowModal(true);
        } catch (error) {
            console.error('Error fetching ID cards:', error.response ? error.response.data : error.message);
        }
    };


    const handleFrontInputChange = (e) => {
        const { name, value } = e.target;
        setFrontInfo(prev => ({ ...prev, [name]: value }));
    };

    const handleBackInputChange = (e) => {
        const { name, value } = e.target;
        setBackInfo(prev => ({ ...prev, [name]: value }));
        if (name === 'academicTrack') {
            setFrontInfo(prev => ({ ...prev, academicTrack: value }));
        }
    };

    const handleFileUpload = (e, type) => {
        const file = e.target.files[0];
        if (file) {
            setFrontInfo(prev => ({ ...prev, [type]: file }));
            // You can still preview the image if needed:
            const reader = new FileReader();
            reader.onloadend = () => {
                setFrontInfo(prev => ({ ...prev, [`${type}Preview`]: reader.result }));
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const formData = new FormData();
        formData.append('cardWidth', frontInfo.cardWidth);
        formData.append('cardHeight', frontInfo.cardHeight);
        formData.append('firstName', frontInfo.firstName);
        formData.append('lastName', frontInfo.lastName);
        formData.append('idNumber', frontInfo.idNumber);
        formData.append('academicTrack', backInfo.academicTrack);
        formData.append('emergencyContactName', backInfo.name);
        formData.append('emergencyContactAddress', backInfo.address);
        formData.append('emergencyContactTelNo', backInfo.telNo);

        if (frontInfo.photo instanceof File) {
            formData.append('photo', frontInfo.photo);
        }
        if (frontInfo.signature instanceof File) {
            formData.append('signature', frontInfo.signature);
        }

        try {
            const response = await axios.post('/id-cards', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });
            console.log('ID Card created:', response.data);
            // Handle success (e.g., show a success message, reset form, etc.)
        } catch (error) {
            console.error('Error creating ID Card:', error.response.data);
            // Handle error (e.g., show error message)
        }
    };

    const handlePrint = () => {
        const printWindow = window.open('', '_blank');
    
        if (!printWindow) {
            console.error('Print window blocked by the browser.');
            return;
        }
    
        const frontCard = idPreviewRef.current.querySelector('.front-of-id');
        const backCard = idPreviewRef.current.querySelector('.back-of-id');
    
        // Replace relative image paths with absolute URLs
        const replaceImagePaths = (html) => {
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');
            const images = doc.querySelectorAll('img');
            images.forEach(img => {
                if (img.src.startsWith('/')) {
                    img.src = window.location.origin + img.src;
                }
            });
            return doc.body.innerHTML;
        };
    
        // Construct front and back card HTML
    
        const frontCardHTML = `
        <h2 style="font-size: 18px; margin-bottom: 10px; text-align: center;">Cordova Public College</h2>
        <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 10px;">
            <div style="position: relative; right: -100px; ">
                <img src="${frontInfo.photoPreview || defaultProfilePic}" alt="Profile Photo" class="photo" style="width: 100px; height: 120px; object-fit: cover;" />
            </div>
            <div style="text-align: right; flex-shrink: 0;">
                <img src="/images/CPC.png" alt="Logo" class="logo" style="width: 75px; height: 75px;" />
                <p style="font-size: 14px; margin-top: 5px; text-align: center;"><strong>${frontInfo.academicTrack || 'BSIT-3D'}</strong></p>
            </div>
        </div>
        <div style="text-align: center;">
            <p style="font-size: 16px; margin: 5px 0; margin-top: 20px;"><strong>${frontInfo.firstName} ${frontInfo.lastName}</strong></p>
            <p style="font-size: 14px; margin: 5px 0;">Student name</p>
            <p style="font-size: 16px; margin: 5px 0;"><strong>${frontInfo.idNumber}</strong></p>
            <p style="font-size: 14px; margin: 5px 0;">ID number</p>
        </div>
        <div style="text-align: center; margin-top: 30px;">
            ${frontInfo.signaturePreview ? `<img src="${frontInfo.signaturePreview}" alt="Signature" style="width: 100px; height: 40px; margin: 10px auto;" />` : '<p>No Signature</p>'}
            <p style="font-size: 12px;"><strong>Student Signature</strong></p>
        </div>
    `;



    
        const backCardHTML = `
            <h2 style="font-size: 18px; margin-bottom: 10px; text-align: center;">In Case of Emergency Contact</h2>
            <div style="text-align: left; padding-left: 20px;">
                <p style="font-size: 14px;"><strong>Name:</strong> ${backInfo.name}</p>
                <p style="font-size: 14px;"><strong>Address:</strong> ${backInfo.address}</p>
                <p style="font-size: 14px;"><strong>Tel No:</strong> ${backInfo.telNo}</p>
            </div>
            <div style="text-align: center; margin-top: 30px;">
                ${backCard.querySelector('.qr-code img') ? `<img src="${backCard.querySelector('.qr-code img').src}" alt="QR Code" style="width: 100px; height: 100px;" />` : '<p>No QR Code available</p>'}
            </div>
        `;
    
        // Write content to the print window
        printWindow.document.write(`
            <html>
            <head>
                <title>Print ID Card</title>
                <style>
                    @page { size: landscape; margin: 0; }
                    body { margin: 0; padding: 20px; display: flex; justify-content: center; align-items: center; height: 100vh; background-color: white; font-family: Arial, sans-serif; }
                    .id-preview { display: flex; gap: 20px; max-width: 100%; height: auto; }
                    .id-preview .card { width: 300px; height: 420px; border: 1px solid #ccc; border-radius: 10px; overflow: hidden; background-color: white; padding: 15px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); position: relative; }
                    .id-preview .card img { max-width: 100%; height: auto; }
                    .id-preview .front-of-id, .id-preview .back-of-id { font-family: Arial, sans-serif; }
                    .id-preview .front-of-id h2, .id-preview .back-of-id h2 { font-size: 18px; margin-top: 0; margin-bottom: 10px; text-align: center; }
                    .id-preview .front-of-id p, .id-preview .back-of-id p { font-size: 14px; margin: 5px 0; }
                    .id-preview .front-of-id .photo { width: 100px; height: 120px; object-fit: cover; background-color: #f0f0f0; }
                    .id-preview .front-of-id .logo { width: 50px; height: 50px; }
                    .id-preview .back-of-id .qr-code { width: 100px; height: 100px; }
                    @media print {
                        body { -webkit-print-color-adjust: exact; }
                        .id-preview { page-break-inside: avoid; }
                    }
                </style>
            </head>
            <body>
                <div class="id-preview">
                    <div class="card front-of-id">
                        ${frontCardHTML}
                    </div>
                    <div class="card back-of-id">
                        ${backCardHTML}
                    </div>
                </div>
            </body>
            </html>
        `);
    
        printWindow.document.close();
    
        // Ensure content is fully loaded before triggering the print
        printWindow.addEventListener('load', () => {
            printWindow.focus();
            printWindow.print();
            printWindow.close();
        });
    };
    
    
    
    
    
    

    return (
        <AuthenticatedLayout user={auth.user}>
            <Head title="ID Maker" />
            <div className="py-6">
                <div className="max-w-7x2 mx-auto sm:px-6 lg:px-8">
                    <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div className="p-6 text-gray-900">
                            <div className="flex justify-between items-center mb-6">
                                <h1 className="text-2xl font-semibold">Create ID</h1>
                                <button
                                    onClick={handleViewAllIds}
                                    className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition duration-150 ease-in-out"
                                >
                                    View All IDs
                                </button>
                            </div>
                            <div className="flex flex-col lg:flex-row gap-6">
                                {/* ID Information form */}
                                <div className="w-full lg:w-1/2 pr-4 overflow-y-auto" style={{ maxHeight: 'calc(100vh - 200px)' }}>
                                    <h2 className="text-xl font-semibold mb-4">ID Information</h2>
                                    <form onSubmit={handleSubmit} className="space-y-4 pr-4">
                                        <div className="flex gap-4">
                                            <div className="w-1/2">
                                                <label htmlFor="cardWidth" className="block text-sm font-medium text-gray-700">Card Width (px)</label>
                                                <input
                                                    type="number"
                                                    id="cardWidth"
                                                    name="cardWidth"
                                                    value={frontInfo.cardWidth}
                                                    onChange={handleFrontInputChange}
                                                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                                                    required
                                                />
                                            </div>
                                            <div className="w-1/2">
                                                <label htmlFor="cardHeight" className="block text-sm font-medium text-gray-700">Card Height (px)</label>
                                                <input
                                                    type="number"
                                                    id="cardHeight"
                                                    name="cardHeight"
                                                    value={frontInfo.cardHeight}
                                                    onChange={handleFrontInputChange}
                                                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                                                    required
                                                />
                                            </div>
                                        </div>
                                        <div>
                                            <label htmlFor="firstName" className="block text-sm font-medium text-gray-700">First Name</label>
                                            <input
                                                type="text"
                                                id="firstName"
                                                name="firstName"
                                                value={frontInfo.firstName}
                                                onChange={handleFrontInputChange}
                                                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                                                required
                                            />
                                        </div>
                                        <div>
                                            <label htmlFor="lastName" className="block text-sm font-medium text-gray-700">Last Name</label>
                                            <input
                                                type="text"
                                                id="lastName"
                                                name="lastName"
                                                value={frontInfo.lastName}
                                                onChange={handleFrontInputChange}
                                                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                                                required
                                            />
                                        </div>
                                        <div>
                                            <label htmlFor="idNumber" className="block text-sm font-medium text-gray-700">Enter ID Number</label>
                                            <input
                                                type="text"
                                                id="idNumber"
                                                name="idNumber"
                                                value={frontInfo.idNumber}
                                                onChange={handleFrontInputChange}
                                                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                                                required
                                            />
                                        </div>
                                        <div>
                                            <label htmlFor="photo" className="block text-sm font-medium text-gray-700">Upload Photo</label>
                                            <input
                                                type="file"
                                                id="photo"
                                                name="photo"
                                                onChange={(e) => handleFileUpload(e, 'photo')}
                                                className="mt-1 block w-full"
                                                accept="image/*"
                                                ref={photoRef}
                                            />
                                        </div>
                                        <div>
                                            <label htmlFor="signature" className="block text-sm font-medium text-gray-700">Student Signature Photo</label>
                                            <input
                                                type="file"
                                                id="signature"
                                                name="signature"
                                                onChange={(e) => handleFileUpload(e, 'signature')}
                                                className="mt-1 block w-full"
                                                accept="image/*"
                                                ref={signatureRef}
                                            />
                                        </div>
                                        <h2 className="text-xl font-semibold mb-4 mt-8">Back of ID</h2>
                                        <div>
                                            <label htmlFor="name" className="block text-sm font-medium text-gray-700">Name</label>
                                            <input
                                                type="text"
                                                id="name"
                                                name="name"
                                                value={backInfo.name}
                                                onChange={handleBackInputChange}
                                                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                                                required
                                            />
                                        </div>
                                        <div>
                                            <label htmlFor="address" className="block text-sm font-medium text-gray-700">Address</label>
                                            <input
                                                type="text"
                                                id="address"
                                                name="address"
                                                value={backInfo.address}
                                                onChange={handleBackInputChange}
                                                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                                                required
                                            />
                                        </div>
                                        <div>
                                            <label htmlFor="telNo" className="block text-sm font-medium text-gray-700">Tel No</label>
                                            <input
                                                type="tel"
                                                id="telNo"
                                                name="telNo"
                                                value={backInfo.telNo}
                                                onChange={handleBackInputChange}
                                                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                                                required
                                            />
                                        </div>
                                        <div>
                                            <label htmlFor="academicTrack" className="block text-sm font-medium text-gray-700">STRANDS IN THE ACADEMIC TRACK</label>
                                            <input
                                                type="text"
                                                id="academicTrack"
                                                name="academicTrack"
                                                value={backInfo.academicTrack}
                                                onChange={handleBackInputChange}
                                                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                                                required
                                            />
                                        </div>
                                        <div>
                                            <button
                                                type="submit"
                                                className="inline-flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 active:bg-blue-800 focus:outline-none focus:border-blue-800 focus:ring focus:ring-blue-300 disabled:opacity-25 transition"
                                            >
                                                Create ID
                                            </button>
                                        </div>
                                    </form>
                                </div>
                                
                                {/* ID Preview */}
                                <div className="w-full lg:w-1/2">
                                    <h2 className="text-xl font-semibold mb-4">ID Preview</h2>
                                    <div ref={idPreviewRef}>
                                        <div className="flex flex-col sm:flex-row gap-4">
                                            {/* Front of ID */}
                                            <div className="front-of-id border-2 border-gray-300 p-4 rounded-lg bg-gray-100 flex-shrink-0" style={{ width: `${frontInfo.cardWidth}px`, height: `${frontInfo.cardHeight}px` }}>
                                                <div className="text-center font-bold text-lg mb-4">CORDOVA PUBLIC COLLEGE</div>
                                                <div className="flex justify-between items-start mb-4">
                                                    {frontInfo.photoPreview ? (
                                                        <img src={frontInfo.photoPreview} alt="Student" className="w-24 h-32 object-cover" />
                                                    ) : (
                                                        <img src={defaultProfilePic} alt="Default Profile" className="w-24 h-32 object-cover" />
                                                    )}
                                                    <div className="text-right flex flex-col items-center"> {/* Changed to flex column and centered */}
                                                        <img src="/images/CPC.png" alt="School Logo" className="w-16 h-16 mb-2" />
                                                        <div className="text-sm font-semibold -ml-2"> {/* Added negative left margin */}
                                                            {frontInfo.academicTrack || 'BSIT-ID'}
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="text-center mb-2">
                                                    <div className="font-bold">{`${frontInfo.firstName} ${frontInfo.lastName}`}</div>
                                                    <div className="text-sm">Student name</div>
                                                </div>
                                                <div className="text-center mb-4">
                                                    <div className="font-bold">{frontInfo.idNumber}</div>
                                                    <div className="text-sm">ID number</div>
                                                </div>
                                                {frontInfo.signaturePreview ? (
                                                    <div className="text-center">
                                                        <img src={frontInfo.signaturePreview} alt="Signature" className="h-12 mx-auto" />
                                                        <div className="text-sm">Student Signature Photo</div>
                                                    </div>
                                                ) : (
                                                    <div className="h-12 bg-gray-300 flex items-center justify-center text-gray-500 text-sm">No Signature</div>
                                                )}
                                            </div>

                                            {/* Back of ID */}
                                            <div className="back-of-id border-2 border-gray-300 p-4 rounded-lg bg-gray-100 flex-shrink-0" style={{ width: `${frontInfo.cardWidth}px`, height: `${frontInfo.cardHeight}px` }}>
                                                <h3 className="font-bold mb-2 text-center">IN CASE OF EMERGENCY CONTACT</h3>
                                                <div className="mb-1"><span className="font-semibold">Name:</span> {backInfo.name}</div>
                                                <div className="mb-1"><span className="font-semibold">Address:</span> {backInfo.address}</div>
                                                <div className="mb-4"><span className="font-semibold">Tel No:</span> {backInfo.telNo}</div>
                                                
                                                {/* QR Code */}
                                                <div className="w-32 h-32 mx-auto">
                                                    <QRCodeSVG 
                                                        value={`${backInfo.name},${backInfo.address},${backInfo.telNo}`}
                                                        size={128}
                                                        level="H"
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <button
                                        onClick={handlePrint}
                                        className="mt-4 px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 transition duration-150 ease-in-out"
                                    >
                                        Print ID
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Modal for All ID Cards */}
            {showModal && (
                <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
                    <div className="relative top-20 mx-auto p-5 border w-11/12 md:w-3/4 lg:w-1/2 shadow-lg rounded-md bg-white">
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="text-lg font-medium">All ID Cards</h3>
                            <button
                                onClick={() => setShowModal(false)}
                                className="text-black close-modal"
                            >
                                &times;
                            </button>
                        </div>
                        
                        {/* Add search bar here */}
                        <input
                            type="text"
                            placeholder="Search ID cards..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full p-2 mb-4 border rounded"
                        />

                        <div className="mt-2 max-h-96 overflow-y-auto">
                            {filteredIdCards.length > 0 ? (
                                filteredIdCards.map((card) => (
                                    <div key={card.id} className="border p-4 rounded-lg mb-2 flex">
                                        <div className="flex-1">
                                            <p><strong>Name:</strong> {card.first_name} {card.last_name}</p>
                                            <p><strong>ID Number:</strong> {card.id_number}</p>
                                            <p><strong>Academic Track:</strong> {card.academic_track}</p>
                                        </div>
                                    </div>
                                ))
                            ) : (
                                <p>No ID cards available.</p>
                            )}
                        </div>
                    </div>
                </div>
            )}
        </AuthenticatedLayout>
    );
};

export default IdMaker;
